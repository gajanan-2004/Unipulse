require('dotenv').config();
const express = require('express');
const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const cors = require('cors');
const path = require('path');

const College = require('./models/College');
const User = require('./models/User');

const app = express();
const PORT = process.env.PORT || 3000;

// ==================== MIDDLEWARE ====================
app.use(cors());
app.use(express.json({ limit: '10mb' }));
app.use(express.static(path.join(__dirname)));

// ==================== MONGODB CONNECTION ====================
mongoose.connect(process.env.MONGODB_URI || 'mongodb://localhost:27017/unipulse')
    .then(() => console.log('✅ Connected to MongoDB'))
    .catch(err => {
        console.error('❌ MongoDB connection error:', err.message);
        process.exit(1);
    });

// ==================== COLLEGE API ====================

// GET all colleges (with optional search/filter)
app.get('/api/colleges', async (req, res) => {
    try {
        const { search, category, type, district } = req.query;
        let filter = {};

        if (category) filter.category = category;
        if (type) filter.type = type;
        if (district) filter.district = district;
        if (search) {
            filter.$or = [
                { name: { $regex: search, $options: 'i' } },
                { district: { $regex: search, $options: 'i' } }
            ];
        }

        const colleges = await College.find(filter).sort({ name: 1 });
        res.json(colleges);
    } catch (err) {
        res.status(500).json({ error: 'Failed to fetch colleges', details: err.message });
    }
});

// GET single college by ID
app.get('/api/colleges/:id', async (req, res) => {
    try {
        const college = await College.findById(req.params.id);
        if (!college) return res.status(404).json({ error: 'College not found' });
        res.json(college);
    } catch (err) {
        res.status(500).json({ error: 'Failed to fetch college', details: err.message });
    }
});

// POST add new college
app.post('/api/colleges', async (req, res) => {
    try {
        const college = new College(req.body);
        await college.save();
        res.status(201).json(college);
    } catch (err) {
        res.status(400).json({ error: 'Failed to add college', details: err.message });
    }
});

// PUT update college
app.put('/api/colleges/:id', async (req, res) => {
    try {
        const college = await College.findByIdAndUpdate(req.params.id, req.body, { new: true, runValidators: true });
        if (!college) return res.status(404).json({ error: 'College not found' });
        res.json(college);
    } catch (err) {
        res.status(400).json({ error: 'Failed to update college', details: err.message });
    }
});

// DELETE college
app.delete('/api/colleges/:id', async (req, res) => {
    try {
        const college = await College.findByIdAndDelete(req.params.id);
        if (!college) return res.status(404).json({ error: 'College not found' });
        res.json({ message: 'College deleted', college });
    } catch (err) {
        res.status(500).json({ error: 'Failed to delete college', details: err.message });
    }
});

// GET college stats
app.get('/api/stats/colleges', async (req, res) => {
    try {
        const total = await College.countDocuments();
        const engineering = await College.countDocuments({ category: 'engineering' });
        const medical = await College.countDocuments({ category: 'medical' });
        const pharmacy = await College.countDocuments({ category: 'pharmacy' });
        const govt = await College.countDocuments({ type: 'Government' });
        const pvt = await College.countDocuments({ type: 'Private' });
        const districts = await College.distinct('district');
        const ratingResult = await College.aggregate([
            { $match: { rating: { $gt: 0 } } },
            { $group: { _id: null, avg: { $avg: '$rating' } } }
        ]);
        const avgRating = ratingResult.length ? ratingResult[0].avg.toFixed(1) : '0';

        res.json({ total, engineering, medical, pharmacy, govt, private: pvt, districts: districts.length, avgRating });
    } catch (err) {
        res.status(500).json({ error: 'Failed to get stats', details: err.message });
    }
});

// GET analytics - colleges by district
app.get('/api/stats/districts', async (req, res) => {
    try {
        const result = await College.aggregate([
            {
                $group: {
                    _id: '$district',
                    engineering: { $sum: { $cond: [{ $eq: ['$category', 'engineering'] }, 1, 0] } },
                    medical: { $sum: { $cond: [{ $eq: ['$category', 'medical'] }, 1, 0] } },
                    pharmacy: { $sum: { $cond: [{ $eq: ['$category', 'pharmacy'] }, 1, 0] } },
                    total: { $sum: 1 }
                }
            },
            { $sort: { total: -1 } }
        ]);
        res.json(result);
    } catch (err) {
        res.status(500).json({ error: 'Failed to get district stats', details: err.message });
    }
});

// ==================== USER / AUTH API ====================

// POST register
app.post('/api/auth/register', async (req, res) => {
    try {
        const { name, email, phone, password } = req.body;

        if (!name || !email || !password) {
            return res.status(400).json({ error: 'Name, email, and password are required.' });
        }

        // Check existing
        const exists = await User.findOne({ email: email.toLowerCase() });
        if (exists) {
            return res.status(409).json({ error: 'An account with this email already exists.' });
        }

        // Hash password
        const salt = await bcrypt.genSalt(10);
        const hashedPassword = await bcrypt.hash(password, salt);

        const user = new User({
            name,
            email: email.toLowerCase(),
            phone: phone || '',
            password: hashedPassword
        });
        await user.save();

        res.status(201).json({
            message: 'Account created successfully!',
            user: { id: user._id, name: user.name, email: user.email, phone: user.phone, createdAt: user.createdAt }
        });
    } catch (err) {
        res.status(500).json({ error: 'Registration failed', details: err.message });
    }
});

// POST login
app.post('/api/auth/login', async (req, res) => {
    try {
        const { email, password } = req.body;

        if (!email || !password) {
            return res.status(400).json({ error: 'Email and password are required.' });
        }

        const user = await User.findOne({ email: email.toLowerCase() });
        if (!user) {
            return res.status(401).json({ error: 'No account found with this email.' });
        }

        const isMatch = await bcrypt.compare(password, user.password);
        if (!isMatch) {
            return res.status(401).json({ error: 'Incorrect password.' });
        }

        res.json({
            message: 'Login successful!',
            user: { id: user._id, name: user.name, email: user.email, phone: user.phone, createdAt: user.createdAt }
        });
    } catch (err) {
        res.status(500).json({ error: 'Login failed', details: err.message });
    }
});

// GET all users (admin)
app.get('/api/users', async (req, res) => {
    try {
        const { search } = req.query;
        let filter = {};
        if (search) {
            filter.$or = [
                { name: { $regex: search, $options: 'i' } },
                { email: { $regex: search, $options: 'i' } },
                { phone: { $regex: search, $options: 'i' } }
            ];
        }
        const users = await User.find(filter).select('-password').sort({ createdAt: -1 });
        res.json(users);
    } catch (err) {
        res.status(500).json({ error: 'Failed to fetch users', details: err.message });
    }
});

// GET user stats (admin)
app.get('/api/stats/users', async (req, res) => {
    try {
        const total = await User.countDocuments();
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        const todayCount = await User.countDocuments({ createdAt: { $gte: today } });
        const weekAgo = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);
        const weekCount = await User.countDocuments({ createdAt: { $gte: weekAgo } });
        const latestUser = await User.findOne().sort({ createdAt: -1 }).select('name createdAt');

        res.json({ total, today: todayCount, week: weekCount, latest: latestUser });
    } catch (err) {
        res.status(500).json({ error: 'Failed to get user stats', details: err.message });
    }
});

// DELETE user (admin)
app.delete('/api/users/:id', async (req, res) => {
    try {
        const user = await User.findByIdAndDelete(req.params.id);
        if (!user) return res.status(404).json({ error: 'User not found' });
        res.json({ message: 'User deleted', user: { name: user.name, email: user.email } });
    } catch (err) {
        res.status(500).json({ error: 'Failed to delete user', details: err.message });
    }
});

// ==================== FALLBACK ROUTE ====================
app.get('*', (req, res) => {
    res.sendFile(path.join(__dirname, 'index.html'));
});

// ==================== START SERVER ====================
app.listen(PORT, () => {
    console.log(`🚀 Unipulse server running at http://localhost:${PORT}`);
});
