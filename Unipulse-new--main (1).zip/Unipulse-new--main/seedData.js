/**
 * Seed Script — Imports all college data from data.js into MongoDB
 * Run once: node seedData.js
 */
require('dotenv').config();
const mongoose = require('mongoose');
const College = require('./models/College');

// Import the college data (data.js uses global `collegeData`)
// We need to evaluate it in a way that gives us the variable
const fs = require('fs');
const dataFileContent = fs.readFileSync('./data.js', 'utf-8');

// Extract the object by evaluating (safe since it's our own file)
let collegeData;
eval(dataFileContent.replace('const collegeData', 'collegeData'));

async function seed() {
    try {
        await mongoose.connect(process.env.MONGODB_URI || 'mongodb://localhost:27017/unipulse');
        console.log('✅ Connected to MongoDB');

        // Clear existing college data
        const deleted = await College.deleteMany({});
        console.log(`🗑️  Cleared ${deleted.deletedCount} existing college records`);

        // Prepare all colleges with their category
        const allColleges = [];

        if (collegeData.engineering) {
            collegeData.engineering.forEach(c => {
                allColleges.push({ ...c, category: 'engineering' });
            });
        }
        if (collegeData.medical) {
            collegeData.medical.forEach(c => {
                allColleges.push({ ...c, category: 'medical' });
            });
        }
        if (collegeData.pharmacy) {
            collegeData.pharmacy.forEach(c => {
                allColleges.push({ ...c, category: 'pharmacy' });
            });
        }

        console.log(`📦 Preparing to insert ${allColleges.length} colleges...`);

        // Insert all at once
        const result = await College.insertMany(allColleges, { ordered: false });
        console.log(`✅ Successfully seeded ${result.length} colleges into MongoDB!`);

        // Summary
        const eng = result.filter(c => c.category === 'engineering').length;
        const med = result.filter(c => c.category === 'medical').length;
        const pha = result.filter(c => c.category === 'pharmacy').length;
        console.log(`   📊 Engineering: ${eng} | Medical: ${med} | Pharmacy: ${pha}`);

    } catch (err) {
        console.error('❌ Seed failed:', err.message);
    } finally {
        await mongoose.disconnect();
        console.log('🔌 Disconnected from MongoDB');
    }
}

seed();
