const mongoose = require('mongoose');

const userSchema = new mongoose.Schema({
    name: { type: String, required: true },
    email: { type: String, required: true, unique: true, lowercase: true, index: true },
    phone: { type: String, default: '' },
    password: { type: String, required: true }
}, {
    timestamps: true
});

module.exports = mongoose.model('User', userSchema);
