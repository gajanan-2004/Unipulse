const mongoose = require('mongoose');

const collegeSchema = new mongoose.Schema({
    name: { type: String, required: true, index: true },
    type: { type: String, required: true },
    district: { type: String, required: true, index: true },
    category: { type: String, enum: ['engineering', 'medical', 'pharmacy'], required: true, index: true },
    branches: [String],
    cutoffRanks: { type: mongoose.Schema.Types.Mixed, default: {} },
    cutoffMarks: { type: mongoose.Schema.Types.Mixed, default: {} },
    fees: { type: String, default: 'N/A' },
    established: { type: Number },
    rating: { type: Number, min: 0, max: 5 }
}, {
    timestamps: true
});

// Text index for search
collegeSchema.index({ name: 'text', district: 'text' });

module.exports = mongoose.model('College', collegeSchema);
