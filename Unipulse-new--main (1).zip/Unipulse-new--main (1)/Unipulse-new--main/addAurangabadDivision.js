const fs = require('fs');
const path = require('path');

const existing = JSON.parse(fs.readFileSync(path.join(__dirname, 'colleges.json'), 'utf8'));
const existingNames = new Set(existing.map(c => c.name));
const newColleges = [];

function add(name, type, district, category, branches, cutoffRanks, cutoffMarks, fees, established, rating) {
    if (existingNames.has(name)) return;
    existingNames.add(name);
    const c = { name, type, district, category, branches, cutoffRanks };
    if (cutoffMarks) c.cutoffMarks = cutoffMarks;
    c.fees = fees; c.established = established; c.rating = rating;
    newColleges.push(c);
}

// Helper to generate CET cutoff data
function cetRanks(g, o, s, st) { return { CET: { General: g, OBC: o, SC: s, ST: st } }; }
function cetMarks(g, o, s, st) { return { CET: { General: g, OBC: o, SC: s, ST: st } }; }
function cetJeeRanks(cg, co, cs, cst, jg, jo, js, jst) {
    return { CET: { General: cg, OBC: co, SC: cs, ST: cst }, JEE: { General: jg, OBC: jo, SC: js, ST: jst } };
}
function neetRanks(g, o, s, st) { return { NEET: { General: g, OBC: o, SC: s, ST: st } }; }
function neetMarks(g, o, s, st) { return { NEET: { General: g, OBC: o, SC: s, ST: st } }; }

const engBranches = ["Computer Science", "Information Technology", "Mechanical Engineering", "Civil Engineering", "Electronics & Telecommunication", "Electrical Engineering"];
const engBranches2 = ["Computer Science", "Mechanical Engineering", "Civil Engineering", "Electrical Engineering"];
const engBranches3 = ["Computer Science", "Information Technology", "Mechanical Engineering", "Civil Engineering"];
const engBranchesSmall = ["Computer Science", "Mechanical Engineering", "Civil Engineering"];
const medBranches = ["MBBS", "MD", "MS"];
const medBranchesFull = ["MBBS", "MD", "MS", "BDS"];
const phaBranches = ["B.Pharm", "D.Pharm", "M.Pharm"];
const phaBranches2 = ["B.Pharm", "D.Pharm"];

// ===================== AURANGABAD (CHHATRAPATI SAMBHAJINAGAR) =====================

// --- Engineering Colleges ---
add("Jawaharlal Nehru Engineering College, Aurangabad", "Private (Autonomous)", "Aurangabad", "engineering",
    engBranches, cetJeeRanks(8000, 15000, 35000, 60000, 55000, 95000, 195000, 315000),
    cetMarks(165, 152, 118, 88), "₹1,20,000/year", 1983, 4.2);

add("Marathwada Institute of Technology, Aurangabad", "Private", "Aurangabad", "engineering",
    engBranches3, cetJeeRanks(12000, 22000, 45000, 75000, 78000, 130000, 240000, 380000),
    cetMarks(158, 145, 112, 85), "₹1,05,000/year", 1997, 3.9);

add("Shivajirao S. Jondhale College of Engineering, Aurangabad", "Private", "Aurangabad", "engineering",
    engBranches2, cetRanks(25000, 38000, 65000, 110000), cetMarks(140, 128, 95, 70), "₹88,000/year", 2005, 3.5);

add("Shreeyash College of Engineering, Aurangabad", "Private", "Aurangabad", "engineering",
    engBranchesSmall, cetRanks(35000, 50000, 80000, 135000), cetMarks(130, 118, 85, 62), "₹78,000/year", 2008, 3.3);

add("Babasaheb Ambedkar Marathwada University Engineering College, Aurangabad", "Government", "Aurangabad", "engineering",
    engBranches, cetJeeRanks(5000, 10000, 28000, 48000, 35000, 70000, 160000, 260000),
    cetMarks(172, 160, 132, 105), "₹48,000/year", 1958, 4.4);

add("Everest College of Engineering, Aurangabad", "Private", "Aurangabad", "engineering",
    engBranches3, cetRanks(30000, 45000, 72000, 120000), cetMarks(135, 122, 90, 65), "₹85,000/year", 2007, 3.4);

add("Aurangabad College of Engineering, Aurangabad", "Private", "Aurangabad", "engineering",
    engBranches2, cetRanks(40000, 58000, 92000, 150000), cetMarks(120, 108, 78, 55), "₹82,000/year", 2009, 3.2);

add("Dr. Babasaheb Ambedkar College of Engineering, Nagpur Road, Aurangabad", "Private", "Aurangabad", "engineering",
    engBranchesSmall, cetRanks(45000, 65000, 100000, 165000), cetMarks(115, 102, 75, 52), "₹75,000/year", 2010, 3.1);

add("Zeal Institute of Engineering, Aurangabad", "Private", "Aurangabad", "engineering",
    engBranches3, cetRanks(38000, 55000, 88000, 142000), cetMarks(122, 110, 80, 58), "₹80,000/year", 2008, 3.3);

add("Shri Guru Gobind Singhji Institute of Engineering and Technology, Nanded Road, Aurangabad", "Private", "Aurangabad", "engineering",
    engBranches, cetJeeRanks(15000, 25000, 50000, 82000, 95000, 155000, 275000, 420000),
    cetMarks(152, 140, 108, 82), "₹1,00,000/year", 1990, 3.8);

add("Sinhgad Technical Education Society College of Engineering, Aurangabad", "Private", "Aurangabad", "engineering",
    engBranches3, cetRanks(28000, 42000, 68000, 112000), cetMarks(135, 122, 90, 65), "₹90,000/year", 2006, 3.5);

add("Padmashri Dr. V.B. Kolte College of Engineering, Waluj, Aurangabad", "Private", "Aurangabad", "engineering",
    engBranches2, cetRanks(42000, 60000, 95000, 155000), cetMarks(118, 108, 78, 55), "₹78,000/year", 2004, 3.3);

add("Hi-Tech Institute of Technology, Aurangabad", "Private", "Aurangabad", "engineering",
    engBranchesSmall, cetRanks(48000, 68000, 108000, 175000), cetMarks(110, 98, 72, 50), "₹72,000/year", 2009, 3.1);

add("Lotus Institute of Engineering & Technology, Aurangabad", "Private", "Aurangabad", "engineering",
    engBranches3, cetRanks(50000, 72000, 112000, 180000), cetMarks(108, 95, 70, 48), "₹70,000/year", 2010, 3.0);

add("Mahatma Gandhi Mission's Jawaharlal Nehru Engineering College, N-6 CIDCO, Aurangabad", "Private", "Aurangabad", "engineering",
    engBranches, cetJeeRanks(10000, 18000, 40000, 68000, 65000, 120000, 220000, 350000),
    cetMarks(162, 148, 115, 88), "₹1,15,000/year", 1983, 4.1);

add("Samarth Institute of Engineering & Technology, Belkheda, Aurangabad", "Private", "Aurangabad", "engineering",
    engBranches2, cetRanks(52000, 74000, 115000, 185000), cetMarks(105, 92, 68, 45), "₹68,000/year", 2011, 2.9);

add("Deogiri College of Engineering & Management Studies, Aurangabad", "Private", "Aurangabad", "engineering",
    engBranches3, cetRanks(22000, 35000, 60000, 100000), cetMarks(142, 130, 95, 72), "₹95,000/year", 2004, 3.6);

add("Milind College of Engineering, Aurangabad", "Private", "Aurangabad", "engineering",
    engBranchesSmall, cetRanks(55000, 78000, 120000, 195000), cetMarks(102, 90, 65, 42), "₹65,000/year", 2012, 2.8);

add("Shri Chhatrapati Shivaji Maharaj Institute of Technology, Aurangabad", "Private", "Aurangabad", "engineering",
    engBranches2, cetRanks(46000, 66000, 102000, 168000), cetMarks(112, 100, 74, 52), "₹75,000/year", 2007, 3.2);

add("Matoshri College of Engineering, Eklahare, Aurangabad", "Private", "Aurangabad", "engineering",
    engBranches3, cetRanks(44000, 62000, 98000, 160000), cetMarks(115, 104, 76, 54), "₹78,000/year", 2006, 3.3);

// Rural Aurangabad engineering
add("Rural Engineering College, Hularghat, Aurangabad", "Private", "Aurangabad", "engineering",
    engBranchesSmall, cetRanks(65000, 88000, 130000, 210000), cetMarks(92, 80, 58, 40), "₹55,000/year", 2013, 2.7);

add("Karmaveer Bhausaheb Hiray College of Engineering, Paithan, Aurangabad", "Private", "Aurangabad", "engineering",
    engBranches2, cetRanks(58000, 80000, 122000, 198000), cetMarks(98, 85, 62, 42), "₹60,000/year", 2011, 2.9);

add("Shri Tulja Bhavani College of Engineering, Kannad, Aurangabad", "Private", "Aurangabad", "engineering",
    engBranchesSmall, cetRanks(62000, 85000, 128000, 205000), cetMarks(95, 82, 60, 40), "₹58,000/year", 2012, 2.8);

add("Vivekanand Institute of Technology, Sillod, Aurangabad", "Private", "Aurangabad", "engineering",
    engBranchesSmall, cetRanks(68000, 92000, 135000, 218000), cetMarks(88, 78, 55, 38), "₹52,000/year", 2014, 2.6);

add("Dnyaneshwar College of Engineering, Phulambri, Aurangabad", "Private", "Aurangabad", "engineering",
    engBranches2, cetRanks(60000, 82000, 125000, 200000), cetMarks(96, 84, 62, 42), "₹58,000/year", 2010, 2.8);

add("Lokshikshan Mandal College of Engineering, Gangapur, Aurangabad", "Private", "Aurangabad", "engineering",
    engBranches3, cetRanks(55000, 76000, 118000, 192000), cetMarks(100, 88, 65, 45), "₹62,000/year", 2008, 3.0);

add("Devgiri Rural Engineering College, Khuldabad, Aurangabad", "Private", "Aurangabad", "engineering",
    engBranchesSmall, cetRanks(70000, 95000, 140000, 225000), cetMarks(85, 75, 52, 35), "₹50,000/year", 2015, 2.5);

// --- Aurangabad Medical ---
add("Indian Institute of Medical Science & Research, Aurangabad", "Private", "Aurangabad", "medical",
    medBranchesFull, neetRanks(28000, 45000, 75000, 110000), neetMarks(515, 475, 375, 315), "₹12,00,000/year", 2002, 3.8);

add("Dr. Hedgewar Smruti Rugna Seva Mandal Medical College, Aurangabad", "Private", "Aurangabad", "medical",
    medBranches, neetRanks(32000, 52000, 82000, 120000), neetMarks(505, 465, 365, 305), "₹10,00,000/year", 2005, 3.6);

add("Shri Bhausaheb Hire Government Medical College, Aurangabad", "Government", "Aurangabad", "medical",
    medBranches, neetRanks(9000, 18000, 42000, 68000), neetMarks(575, 535, 435, 375), "₹50,000/year", 1988, 4.3);

add("Mahatma Gandhi Mission's Medical College, Aurangabad", "Private", "Aurangabad", "medical",
    medBranchesFull, neetRanks(22000, 38000, 65000, 95000), neetMarks(525, 485, 385, 325), "₹11,00,000/year", 1990, 4.0);

add("Government Dental College, Aurangabad", "Government", "Aurangabad", "medical",
    ["BDS", "MDS"], neetRanks(18000, 32000, 58000, 88000), neetMarks(540, 498, 398, 338), "₹45,000/year", 1982, 4.1);

add("Rural Medical College, Paithan, Aurangabad", "Private", "Aurangabad", "medical",
    medBranches, neetRanks(38000, 58000, 90000, 130000), neetMarks(490, 450, 350, 290), "₹8,00,000/year", 2010, 3.4);

add("Marathwada Medical & Research Institute, Aurangabad", "Private", "Aurangabad", "medical",
    medBranches, neetRanks(35000, 55000, 85000, 125000), neetMarks(498, 458, 358, 298), "₹9,00,000/year", 2008, 3.5);

add("Dr. Babasaheb Ambedkar Ayurvedic Medical College, Aurangabad", "Private", "Aurangabad", "medical",
    ["BAMS", "MD (Ayurveda)"], neetRanks(45000, 65000, 100000, 150000), neetMarks(470, 430, 330, 275), "₹5,00,000/year", 1995, 3.3);

add("Shivaji Nagar Homeopathic Medical College, Aurangabad", "Private", "Aurangabad", "medical",
    ["BHMS", "MD (Homeopathy)"], neetRanks(50000, 72000, 110000, 165000), neetMarks(455, 415, 315, 260), "₹4,00,000/year", 1998, 3.1);

add("Government Unani Medical College, Aurangabad", "Government", "Aurangabad", "medical",
    ["BUMS", "MD (Unani)"], neetRanks(42000, 62000, 95000, 140000), neetMarks(478, 438, 338, 280), "₹35,000/year", 1985, 3.5);

// --- Aurangabad Pharmacy ---
add("Government College of Pharmacy, Aurangabad", "Government", "Aurangabad", "pharmacy",
    phaBranches, cetRanks(5000, 12000, 28000, 48000), cetMarks(168, 155, 125, 98), "₹40,000/year", 1982, 4.2);

add("MGM College of Pharmacy, Aurangabad", "Private", "Aurangabad", "pharmacy",
    phaBranches, cetRanks(12000, 22000, 42000, 70000), cetMarks(150, 135, 102, 78), "₹75,000/year", 1995, 3.8);

add("Shreeyash Institute of Pharmaceutical Sciences, Aurangabad", "Private", "Aurangabad", "pharmacy",
    phaBranches2, cetRanks(20000, 35000, 58000, 92000), cetMarks(138, 125, 92, 68), "₹65,000/year", 2005, 3.5);

add("Marathwada College of Pharmacy, CIDCO, Aurangabad", "Private", "Aurangabad", "pharmacy",
    phaBranches, cetRanks(15000, 28000, 50000, 82000), cetMarks(145, 130, 98, 72), "₹70,000/year", 2001, 3.6);

add("Shri Dnyaneshwar College of Pharmacy, Paithan Road, Aurangabad", "Private", "Aurangabad", "pharmacy",
    phaBranches2, cetRanks(25000, 40000, 65000, 105000), cetMarks(132, 118, 88, 62), "₹58,000/year", 2008, 3.3);

add("Hi-Tech College of Pharmacy, Aurangabad", "Private", "Aurangabad", "pharmacy",
    phaBranches2, cetRanks(28000, 45000, 72000, 115000), cetMarks(128, 115, 82, 58), "₹55,000/year", 2010, 3.1);

add("Padmashri Vikhe Patil College of Pharmacy, Aurangabad", "Private", "Aurangabad", "pharmacy",
    phaBranches, cetRanks(18000, 30000, 52000, 85000), cetMarks(142, 128, 95, 70), "₹68,000/year", 2003, 3.5);

add("Rural College of Pharmacy, Kannad, Aurangabad", "Private", "Aurangabad", "pharmacy",
    phaBranches2, cetRanks(32000, 48000, 78000, 125000), cetMarks(125, 112, 80, 55), "₹48,000/year", 2012, 2.9);

add("Devgiri College of Pharmacy, Aurangabad", "Private", "Aurangabad", "pharmacy",
    phaBranches2, cetRanks(22000, 38000, 62000, 100000), cetMarks(135, 122, 90, 65), "₹62,000/year", 2006, 3.4);

add("Lokshikshan Mandal College of Pharmacy, Gangapur, Aurangabad", "Private", "Aurangabad", "pharmacy",
    phaBranches2, cetRanks(35000, 52000, 82000, 132000), cetMarks(120, 108, 78, 55), "₹45,000/year", 2013, 2.8);

// ===================== JALNA =====================

// --- Engineering ---
add("Mahatma Gandhi Mission's College of Engineering, Jalna", "Private", "Jalna", "engineering",
    engBranches3, cetJeeRanks(18000, 30000, 55000, 90000, 115000, 175000, 300000, 450000),
    cetMarks(148, 135, 100, 75), "₹92,000/year", 2001, 3.7);

add("Government Polytechnic & Engineering College, Jalna", "Government", "Jalna", "engineering",
    engBranches2, cetJeeRanks(22000, 35000, 60000, 100000, 140000, 200000, 320000, 480000),
    cetMarks(142, 130, 95, 70), "₹42,000/year", 1985, 3.9);

add("Shri Shivaji College of Engineering, Jalna", "Private", "Jalna", "engineering",
    engBranches3, cetRanks(28000, 42000, 68000, 112000), cetMarks(135, 122, 90, 65), "₹85,000/year", 2004, 3.5);

add("Dnyandeep Institute of Engineering, Jalna", "Private", "Jalna", "engineering",
    engBranchesSmall, cetRanks(38000, 55000, 88000, 142000), cetMarks(122, 110, 80, 58), "₹75,000/year", 2008, 3.2);

add("Nutan Engineering College, Ambad, Jalna", "Private", "Jalna", "engineering",
    engBranches2, cetRanks(42000, 60000, 95000, 155000), cetMarks(118, 105, 78, 55), "₹72,000/year", 2009, 3.1);

add("Marathwada Shikshan Prasarak Mandal College of Engineering, Jalna", "Private", "Jalna", "engineering",
    engBranches3, cetRanks(32000, 48000, 78000, 125000), cetMarks(130, 118, 85, 62), "₹80,000/year", 2005, 3.4);

add("Sarvodaya College of Engineering, Jafrabad, Jalna", "Private", "Jalna", "engineering",
    engBranchesSmall, cetRanks(55000, 78000, 120000, 195000), cetMarks(102, 90, 65, 42), "₹60,000/year", 2012, 2.8);

add("Matoshri Pratishthan College of Engineering, Partur, Jalna", "Private", "Jalna", "engineering",
    engBranches2, cetRanks(50000, 72000, 112000, 180000), cetMarks(108, 95, 70, 48), "₹65,000/year", 2010, 3.0);

add("Rural Institute of Technology, Badnapur, Jalna", "Private", "Jalna", "engineering",
    engBranchesSmall, cetRanks(60000, 82000, 125000, 200000), cetMarks(96, 84, 62, 42), "₹55,000/year", 2013, 2.7);

add("Siddheshwar College of Engineering, Mantha, Jalna", "Private", "Jalna", "engineering",
    engBranchesSmall, cetRanks(65000, 88000, 132000, 212000), cetMarks(90, 80, 58, 38), "₹52,000/year", 2014, 2.6);

add("Jalna Institute of Engineering & Technology, Jalna", "Private", "Jalna", "engineering",
    engBranches3, cetRanks(35000, 52000, 82000, 132000), cetMarks(128, 115, 82, 60), "₹78,000/year", 2006, 3.3);

add("Swami Vivekanand College of Engineering, Jalna", "Private", "Jalna", "engineering",
    engBranches2, cetRanks(45000, 65000, 100000, 165000), cetMarks(112, 100, 74, 52), "₹70,000/year", 2007, 3.1);

add("Kranti Institute of Engineering, Ghansawangi, Jalna", "Private", "Jalna", "engineering",
    engBranchesSmall, cetRanks(68000, 92000, 138000, 220000), cetMarks(88, 78, 55, 38), "₹48,000/year", 2015, 2.5);

// --- Jalna Medical ---
add("Government Medical College, Jalna", "Government", "Jalna", "medical",
    medBranches, neetRanks(14000, 25000, 50000, 78000), neetMarks(550, 510, 410, 350), "₹50,000/year", 2010, 4.0);

add("MGM Medical College & Hospital, Jalna", "Private", "Jalna", "medical",
    medBranchesFull, neetRanks(30000, 48000, 78000, 115000), neetMarks(510, 470, 370, 310), "₹10,00,000/year", 2005, 3.7);

add("Jalna Ayurvedic Medical College, Jalna", "Private", "Jalna", "medical",
    ["BAMS", "MD (Ayurveda)"], neetRanks(48000, 68000, 105000, 155000), neetMarks(460, 420, 322, 268), "₹4,50,000/year", 2000, 3.2);

add("Rural Medical Training Institute, Ambad, Jalna", "Private", "Jalna", "medical",
    medBranches, neetRanks(40000, 60000, 92000, 135000), neetMarks(485, 445, 345, 288), "₹7,50,000/year", 2012, 3.3);

add("Shri Sant Dnyaneshwar Medical College, Partur, Jalna", "Private", "Jalna", "medical",
    medBranches, neetRanks(35000, 55000, 85000, 125000), neetMarks(498, 458, 358, 298), "₹8,50,000/year", 2008, 3.5);

// --- Jalna Pharmacy ---
add("Government College of Pharmacy, Jalna", "Government", "Jalna", "pharmacy",
    phaBranches, cetRanks(8000, 15000, 32000, 55000), cetMarks(162, 148, 118, 92), "₹38,000/year", 1988, 4.0);

add("MGM College of Pharmacy, Jalna", "Private", "Jalna", "pharmacy",
    phaBranches, cetRanks(15000, 28000, 48000, 78000), cetMarks(148, 132, 100, 75), "₹68,000/year", 2002, 3.6);

add("Sai College of Pharmacy, Jalna", "Private", "Jalna", "pharmacy",
    phaBranches2, cetRanks(22000, 38000, 62000, 100000), cetMarks(135, 122, 90, 65), "₹58,000/year", 2008, 3.3);

add("Shri Bharat College of Pharmacy, Ambad, Jalna", "Private", "Jalna", "pharmacy",
    phaBranches2, cetRanks(28000, 45000, 72000, 115000), cetMarks(128, 115, 82, 58), "₹50,000/year", 2010, 3.0);

add("Marathwada College of Pharmacy, Jalna", "Private", "Jalna", "pharmacy",
    phaBranches2, cetRanks(25000, 42000, 68000, 108000), cetMarks(130, 118, 85, 60), "₹55,000/year", 2006, 3.2);

add("Rural College of Pharmacy, Partur, Jalna", "Private", "Jalna", "pharmacy",
    phaBranches2, cetRanks(32000, 50000, 78000, 128000), cetMarks(122, 110, 78, 55), "₹42,000/year", 2013, 2.8);

// ===================== BEED =====================

// --- Engineering ---
add("Karmaveer Bhaurao Patil College of Engineering, Satara Road, Beed", "Private", "Beed", "engineering",
    engBranches3, cetRanks(30000, 45000, 72000, 120000), cetMarks(132, 120, 88, 65), "₹82,000/year", 2004, 3.5);

add("Shri Guru Gobind Singhji College of Engineering, Beed", "Private", "Beed", "engineering",
    engBranches2, cetRanks(35000, 52000, 82000, 135000), cetMarks(128, 115, 82, 60), "₹78,000/year", 2006, 3.3);

add("Government Engineering College, Beed", "Government", "Beed", "engineering",
    engBranches, cetJeeRanks(20000, 32000, 58000, 95000, 130000, 190000, 310000, 470000),
    cetMarks(145, 132, 98, 72), "₹42,000/year", 1995, 3.8);

add("Dnyaneshwar Institute of Engineering, Beed", "Private", "Beed", "engineering",
    engBranchesSmall, cetRanks(45000, 65000, 100000, 165000), cetMarks(112, 100, 74, 52), "₹70,000/year", 2009, 3.1);

add("Lokshikshan Mandal Engineering College, Majalgaon, Beed", "Private", "Beed", "engineering",
    engBranches2, cetRanks(50000, 72000, 112000, 180000), cetMarks(108, 95, 70, 48), "₹65,000/year", 2010, 2.9);

add("Rural Engineering College, Ashti, Beed", "Private", "Beed", "engineering",
    engBranchesSmall, cetRanks(62000, 85000, 128000, 205000), cetMarks(95, 82, 60, 40), "₹55,000/year", 2012, 2.7);

add("Matoshri Vidyalaya Engineering College, Georai, Beed", "Private", "Beed", "engineering",
    engBranchesSmall, cetRanks(58000, 80000, 122000, 198000), cetMarks(98, 85, 62, 42), "₹58,000/year", 2011, 2.8);

add("Ambedkar College of Engineering, Kaij, Beed", "Private", "Beed", "engineering",
    engBranches2, cetRanks(52000, 74000, 115000, 185000), cetMarks(105, 92, 68, 45), "₹62,000/year", 2010, 2.9);

add("Shivaji Maharaj College of Engineering, Parli Vaijnath, Beed", "Private", "Beed", "engineering",
    engBranchesSmall, cetRanks(65000, 88000, 132000, 212000), cetMarks(92, 80, 58, 38), "₹52,000/year", 2013, 2.6);

add("Kranti Agrini College of Engineering, Dharur, Beed", "Private", "Beed", "engineering",
    engBranchesSmall, cetRanks(68000, 92000, 138000, 220000), cetMarks(88, 78, 55, 38), "₹48,000/year", 2014, 2.5);

add("Beed Institute of Technology, Beed", "Private", "Beed", "engineering",
    engBranches3, cetRanks(40000, 58000, 92000, 150000), cetMarks(118, 105, 78, 55), "₹75,000/year", 2007, 3.2);

add("Nutan College of Engineering, Wadwani, Beed", "Private", "Beed", "engineering",
    engBranches2, cetRanks(56000, 78000, 120000, 195000), cetMarks(100, 88, 65, 42), "₹55,000/year", 2012, 2.8);

// --- Beed Medical ---
add("Government Medical College, Beed", "Government", "Beed", "medical",
    medBranches, neetRanks(15000, 28000, 52000, 80000), neetMarks(548, 508, 408, 348), "₹50,000/year", 2015, 3.8);

add("Swami Ramanand Teerth Rural Medical College, Ambajogai, Beed", "Government", "Beed", "medical",
    medBranches, neetRanks(12000, 22000, 45000, 72000), neetMarks(560, 520, 420, 360), "₹48,000/year", 1986, 4.2);

add("Private Medical College, Parli Vaijnath, Beed", "Private", "Beed", "medical",
    medBranchesFull, neetRanks(32000, 52000, 82000, 120000), neetMarks(505, 465, 365, 305), "₹9,00,000/year", 2008, 3.5);

add("Beed Ayurvedic Medical College, Beed", "Private", "Beed", "medical",
    ["BAMS", "MD (Ayurveda)"], neetRanks(50000, 72000, 110000, 165000), neetMarks(455, 415, 315, 260), "₹4,00,000/year", 2002, 3.1);

add("Rural Homeopathic Medical College, Georai, Beed", "Private", "Beed", "medical",
    ["BHMS", "MD (Homeopathy)"], neetRanks(55000, 78000, 118000, 175000), neetMarks(445, 405, 308, 252), "₹3,50,000/year", 2005, 3.0);

// --- Beed Pharmacy ---
add("Government College of Pharmacy, Ambajogai, Beed", "Government", "Beed", "pharmacy",
    phaBranches, cetRanks(8000, 15000, 32000, 55000), cetMarks(162, 148, 118, 92), "₹38,000/year", 1990, 4.0);

add("Shri Dnyaneshwar College of Pharmacy, Beed", "Private", "Beed", "pharmacy",
    phaBranches2, cetRanks(18000, 32000, 55000, 88000), cetMarks(142, 128, 95, 70), "₹62,000/year", 2004, 3.4);

add("Beed College of Pharmacy, Beed", "Private", "Beed", "pharmacy",
    phaBranches, cetRanks(22000, 38000, 62000, 100000), cetMarks(135, 122, 90, 65), "₹58,000/year", 2007, 3.2);

add("Rural Institute of Pharmacy, Ashti, Beed", "Private", "Beed", "pharmacy",
    phaBranches2, cetRanks(30000, 48000, 75000, 120000), cetMarks(125, 112, 80, 55), "₹45,000/year", 2012, 2.8);

add("Matoshri College of Pharmacy, Georai, Beed", "Private", "Beed", "pharmacy",
    phaBranches2, cetRanks(25000, 42000, 68000, 108000), cetMarks(130, 118, 85, 60), "₹52,000/year", 2009, 3.0);

// ===================== OSMANABAD (DHARASHIV) =====================

// --- Engineering ---
add("Government College of Engineering, Osmanabad", "Government", "Osmanabad", "engineering",
    engBranches, cetJeeRanks(18000, 30000, 55000, 90000, 115000, 175000, 300000, 450000),
    cetMarks(148, 135, 100, 75), "₹42,000/year", 1990, 3.9);

add("Shri Shivaji Institute of Engineering, Osmanabad", "Private", "Osmanabad", "engineering",
    engBranches3, cetRanks(30000, 45000, 72000, 120000), cetMarks(132, 120, 88, 65), "₹80,000/year", 2004, 3.5);

add("Dnyaneshwar Engineering College, Tuljapur, Osmanabad", "Private", "Osmanabad", "engineering",
    engBranches2, cetRanks(40000, 58000, 92000, 150000), cetMarks(120, 108, 78, 55), "₹72,000/year", 2007, 3.2);

add("Keshav College of Engineering, Osmanabad", "Private", "Osmanabad", "engineering",
    engBranchesSmall, cetRanks(48000, 68000, 108000, 175000), cetMarks(110, 98, 72, 50), "₹65,000/year", 2009, 3.0);

add("Rural Institute of Engineering, Kalamb, Osmanabad", "Private", "Osmanabad", "engineering",
    engBranchesSmall, cetRanks(58000, 80000, 122000, 198000), cetMarks(98, 85, 62, 42), "₹55,000/year", 2012, 2.8);

add("Babasaheb Ambedkar College of Engineering, Lohara, Osmanabad", "Private", "Osmanabad", "engineering",
    engBranches2, cetRanks(55000, 76000, 118000, 192000), cetMarks(100, 88, 65, 45), "₹58,000/year", 2010, 2.9);

add("Shri Tuljabhavani College of Engineering, Tuljapur, Osmanabad", "Private", "Osmanabad", "engineering",
    engBranches3, cetRanks(35000, 52000, 82000, 132000), cetMarks(128, 115, 82, 60), "₹75,000/year", 2005, 3.3);

add("Matoshri College of Engineering, Omerga, Osmanabad", "Private", "Osmanabad", "engineering",
    engBranchesSmall, cetRanks(62000, 85000, 128000, 205000), cetMarks(95, 82, 60, 40), "₹52,000/year", 2013, 2.7);

add("Osmanabad Institute of Technology, Osmanabad", "Private", "Osmanabad", "engineering",
    engBranches2, cetRanks(45000, 65000, 100000, 165000), cetMarks(112, 100, 74, 52), "₹68,000/year", 2008, 3.1);

add("Prerna College of Engineering, Bhoom, Osmanabad", "Private", "Osmanabad", "engineering",
    engBranchesSmall, cetRanks(65000, 88000, 132000, 212000), cetMarks(92, 80, 58, 38), "₹48,000/year", 2014, 2.6);

// --- Osmanabad Medical ---
add("Government Medical College, Osmanabad", "Government", "Osmanabad", "medical",
    medBranches, neetRanks(16000, 28000, 55000, 85000), neetMarks(545, 505, 405, 345), "₹50,000/year", 2012, 3.8);

add("Shri Tuljabhavani Medical College, Tuljapur, Osmanabad", "Private", "Osmanabad", "medical",
    medBranchesFull, neetRanks(30000, 48000, 78000, 115000), neetMarks(510, 470, 370, 310), "₹9,50,000/year", 2008, 3.5);

add("Osmanabad Ayurvedic Medical College, Osmanabad", "Private", "Osmanabad", "medical",
    ["BAMS", "MD (Ayurveda)"], neetRanks(48000, 68000, 105000, 155000), neetMarks(460, 420, 322, 268), "₹4,00,000/year", 2000, 3.2);

add("Rural Medical & Research Centre, Kalamb, Osmanabad", "Private", "Osmanabad", "medical",
    medBranches, neetRanks(38000, 58000, 90000, 130000), neetMarks(490, 450, 350, 290), "₹7,50,000/year", 2010, 3.3);

// --- Osmanabad Pharmacy ---
add("Government College of Pharmacy, Osmanabad", "Government", "Osmanabad", "pharmacy",
    phaBranches, cetRanks(10000, 18000, 35000, 60000), cetMarks(158, 145, 115, 88), "₹38,000/year", 1992, 3.9);

add("Osmanabad College of Pharmacy, Osmanabad", "Private", "Osmanabad", "pharmacy",
    phaBranches2, cetRanks(20000, 35000, 58000, 92000), cetMarks(138, 125, 92, 68), "₹58,000/year", 2005, 3.3);

add("Shri Tuljabhavani College of Pharmacy, Tuljapur, Osmanabad", "Private", "Osmanabad", "pharmacy",
    phaBranches2, cetRanks(25000, 42000, 68000, 108000), cetMarks(130, 118, 85, 60), "₹52,000/year", 2008, 3.1);

add("Rural Pharmacy College, Kalamb, Osmanabad", "Private", "Osmanabad", "pharmacy",
    phaBranches2, cetRanks(30000, 48000, 75000, 120000), cetMarks(125, 112, 80, 55), "₹42,000/year", 2012, 2.8);

// ===================== LATUR =====================

// --- Engineering ---
add("Government College of Engineering, Latur", "Government", "Latur", "engineering",
    engBranches, cetJeeRanks(12000, 22000, 45000, 75000, 78000, 130000, 240000, 380000),
    cetMarks(158, 145, 112, 85), "₹42,000/year", 1985, 4.1);

add("N.B. Navale Sinhgad College of Engineering, Latur", "Private", "Latur", "engineering",
    engBranches3, cetRanks(25000, 38000, 65000, 108000), cetMarks(138, 125, 92, 68), "₹88,000/year", 2002, 3.6);

add("Vilasrao Deshmukh College of Engineering, Latur", "Private", "Latur", "engineering",
    engBranches2, cetRanks(30000, 45000, 72000, 120000), cetMarks(132, 120, 88, 65), "₹82,000/year", 2005, 3.5);

add("Shri Guru Gobind Singhji Institute of Technology, Latur", "Private", "Latur", "engineering",
    engBranches3, cetRanks(20000, 32000, 58000, 95000), cetMarks(145, 132, 98, 72), "₹95,000/year", 1998, 3.8);

add("Latur Institute of Engineering & Technology, Latur", "Private", "Latur", "engineering",
    engBranches2, cetRanks(35000, 52000, 82000, 135000), cetMarks(128, 115, 82, 60), "₹78,000/year", 2006, 3.3);

add("Dnyaneshwar College of Engineering, Chakur, Latur", "Private", "Latur", "engineering",
    engBranchesSmall, cetRanks(48000, 68000, 108000, 175000), cetMarks(110, 98, 72, 50), "₹65,000/year", 2009, 3.0);

add("Ambedkar Institute of Engineering, Nilanga, Latur", "Private", "Latur", "engineering",
    engBranches2, cetRanks(52000, 74000, 115000, 185000), cetMarks(105, 92, 68, 45), "₹60,000/year", 2010, 2.9);

add("Rural Engineering College, Ausa, Latur", "Private", "Latur", "engineering",
    engBranchesSmall, cetRanks(60000, 82000, 125000, 200000), cetMarks(96, 84, 62, 42), "₹52,000/year", 2012, 2.7);

add("Matoshri Engineering College, Udgir, Latur", "Private", "Latur", "engineering",
    engBranches3, cetRanks(42000, 60000, 95000, 155000), cetMarks(118, 105, 78, 55), "₹72,000/year", 2007, 3.1);

add("Nutan College of Engineering, Renapur, Latur", "Private", "Latur", "engineering",
    engBranchesSmall, cetRanks(58000, 80000, 122000, 198000), cetMarks(98, 85, 62, 42), "₹55,000/year", 2011, 2.8);

add("Mahatma Phule Engineering College, Deoni, Latur", "Private", "Latur", "engineering",
    engBranchesSmall, cetRanks(65000, 88000, 132000, 212000), cetMarks(92, 80, 58, 38), "₹48,000/year", 2013, 2.6);

add("Keshav Institute of Technology, Latur", "Private", "Latur", "engineering",
    engBranches2, cetRanks(40000, 58000, 92000, 150000), cetMarks(120, 108, 78, 55), "₹70,000/year", 2008, 3.2);

// --- Latur Medical ---
add("Vilasrao Deshmukh Government Medical College, Latur", "Government", "Latur", "medical",
    medBranches, neetRanks(10000, 20000, 42000, 68000), neetMarks(568, 528, 428, 368), "₹50,000/year", 1986, 4.3);

add("Mimsr Medical College, Latur", "Private", "Latur", "medical",
    medBranchesFull, neetRanks(22000, 38000, 65000, 95000), neetMarks(525, 485, 385, 325), "₹10,00,000/year", 1998, 4.0);

add("Shri B.M. Patil Dharashiv Medical College, Latur", "Private", "Latur", "medical",
    medBranches, neetRanks(28000, 45000, 75000, 110000), neetMarks(515, 475, 375, 315), "₹9,00,000/year", 2005, 3.7);

add("Indian Institute of Medical Sciences, Udgir, Latur", "Private", "Latur", "medical",
    medBranches, neetRanks(35000, 55000, 85000, 125000), neetMarks(498, 458, 358, 298), "₹8,00,000/year", 2010, 3.4);

add("Latur Dental College, Latur", "Private", "Latur", "medical",
    ["BDS", "MDS"], neetRanks(25000, 42000, 68000, 100000), neetMarks(520, 480, 380, 320), "₹6,00,000/year", 2003, 3.5);

add("Matoshri Ayurvedic Medical College, Nilanga, Latur", "Private", "Latur", "medical",
    ["BAMS", "MD (Ayurveda)"], neetRanks(48000, 68000, 105000, 155000), neetMarks(460, 420, 322, 268), "₹4,00,000/year", 2001, 3.1);

add("Rural Medical College, Ausa, Latur", "Private", "Latur", "medical",
    medBranches, neetRanks(40000, 60000, 92000, 135000), neetMarks(485, 445, 345, 288), "₹7,00,000/year", 2012, 3.2);

// --- Latur Pharmacy ---
add("Government College of Pharmacy, Latur", "Government", "Latur", "pharmacy",
    phaBranches, cetRanks(6000, 12000, 28000, 48000), cetMarks(165, 152, 122, 95), "₹38,000/year", 1988, 4.1);

add("MIMSR College of Pharmacy, Latur", "Private", "Latur", "pharmacy",
    phaBranches, cetRanks(12000, 22000, 42000, 70000), cetMarks(150, 135, 102, 78), "₹72,000/year", 2000, 3.7);

add("Vilasrao Deshmukh College of Pharmacy, Latur", "Private", "Latur", "pharmacy",
    phaBranches2, cetRanks(18000, 32000, 55000, 88000), cetMarks(142, 128, 95, 70), "₹62,000/year", 2005, 3.4);

add("Shri Guru Gobind Singhji College of Pharmacy, Latur", "Private", "Latur", "pharmacy",
    phaBranches, cetRanks(15000, 28000, 48000, 78000), cetMarks(148, 132, 100, 75), "₹68,000/year", 2002, 3.6);

add("Rural College of Pharmacy, Udgir, Latur", "Private", "Latur", "pharmacy",
    phaBranches2, cetRanks(25000, 42000, 68000, 108000), cetMarks(130, 118, 85, 60), "₹48,000/year", 2010, 3.0);

add("Latur Pharmacy College, Latur", "Private", "Latur", "pharmacy",
    phaBranches2, cetRanks(22000, 38000, 62000, 100000), cetMarks(135, 122, 90, 65), "₹55,000/year", 2007, 3.2);

add("Matoshri College of Pharmacy, Nilanga, Latur", "Private", "Latur", "pharmacy",
    phaBranches2, cetRanks(30000, 48000, 75000, 120000), cetMarks(125, 112, 80, 55), "₹42,000/year", 2012, 2.8);

// ================================================
// Merge and write
const all = [...existing, ...newColleges];
fs.writeFileSync(path.join(__dirname, 'colleges.json'), JSON.stringify(all, null, 4), 'utf8');

// Summary
const districts = ['Aurangabad', 'Jalna', 'Beed', 'Osmanabad', 'Latur'];
console.log(`\n✅ Added ${newColleges.length} new colleges to Aurangabad Division`);
console.log(`📊 Total colleges in database: ${all.length}\n`);
districts.forEach(dist => {
    const c = all.filter(x => x.district === dist);
    console.log(`${dist}: ${c.length} total (Eng: ${c.filter(x => x.category === 'engineering').length}, Med: ${c.filter(x => x.category === 'medical').length}, Pha: ${c.filter(x => x.category === 'pharmacy').length})`);
});
console.log(`\nDistricts covered: ${[...new Set(all.map(c => c.district))].sort().join(', ')}`);
