/**
 * Seed Script — Imports colleges from colleges.json into MongoDB Atlas
 *
 * Usage:
 *   node seedData.js              (adds new colleges, skips duplicates)
 *   node seedData.js --reset      (deletes ALL existing colleges first, then adds fresh)
 *
 * Requires: MONGODB_URI in .env file pointing to MongoDB Atlas
 * Data file: colleges.json (must be in the same directory)
 */
require('dotenv').config();
const mongoose = require('mongoose');
const fs = require('fs');
const path = require('path');
const College = require('./models/College');

const JSON_FILE = path.join(__dirname, 'colleges.json');
const RESET_FLAG = process.argv.includes('--reset');

// Validate .env URI
if (!process.env.MONGODB_URI || process.env.MONGODB_URI.includes('YOUR_USERNAME')) {
    console.error('❌ ERROR: Please update your .env file with a real MongoDB Atlas URI.');
    console.error('   Edit .env and replace YOUR_USERNAME, YOUR_PASSWORD, and cluster details.');
    console.error('   Example: MONGODB_URI=mongodb+srv://john:pass123@cluster0.abc12.mongodb.net/unipulse?retryWrites=true&w=majority');
    process.exit(1);
}

async function seed() {
    try {
        // 1. Read JSON file
        if (!fs.existsSync(JSON_FILE)) {
            console.error('❌ File not found: colleges.json');
            process.exit(1);
        }

        const rawData = fs.readFileSync(JSON_FILE, 'utf-8');
        let colleges;
        try {
            colleges = JSON.parse(rawData);
        } catch (parseErr) {
            console.error('❌ Invalid JSON in colleges.json:', parseErr.message);
            process.exit(1);
        }

        if (!Array.isArray(colleges)) {
            console.error('❌ colleges.json must contain an array of college objects.');
            process.exit(1);
        }

        console.log(`📄 Loaded ${colleges.length} colleges from colleges.json`);

        // 2. Connect to MongoDB Atlas
        console.log('🔌 Connecting to MongoDB Atlas...');
        await mongoose.connect(process.env.MONGODB_URI, {
            serverSelectionTimeoutMS: 10000, // 10s timeout
        });
        console.log('✅ Connected to MongoDB Atlas!');

        // 3. Optionally reset existing data
        if (RESET_FLAG) {
            const deleted = await College.deleteMany({});
            console.log(`🗑️  Cleared ${deleted.deletedCount} existing college records`);
        } else {
            const existing = await College.countDocuments();
            if (existing > 0) {
                console.log(`ℹ️  Found ${existing} existing records. Use --reset flag to clear them first.`);
            }
        }

        // 4. Validate and insert
        console.log(`\n📦 Inserting ${colleges.length} colleges into Atlas...`);

        let successCount = 0;
        let errorCount = 0;
        const errors = [];

        for (let i = 0; i < colleges.length; i++) {
            try {
                // Check for duplicate by name before inserting
                const exists = await College.findOne({ name: colleges[i].name });
                if (exists) {
                    // Skip duplicate silently
                    continue;
                }
                const college = new College(colleges[i]);
                await college.save();
                successCount++;
                if (successCount % 10 === 0) {
                    process.stdout.write(`   ✅ ${successCount} inserted so far...\r`);
                }
            } catch (err) {
                errorCount++;
                errors.push({
                    index: i + 1,
                    name: colleges[i].name || '(no name)',
                    error: err.message
                });
            }
        }

        // 5. Summary
        console.log('\n\n========== SEED RESULTS ==========');
        console.log(`✅ Successfully inserted: ${successCount} colleges`);

        if (errorCount > 0) {
            console.log(`❌ Failed: ${errorCount} colleges`);
            console.log('\nFailed entries:');
            errors.forEach(e => {
                console.log(`   #${e.index} "${e.name}" → ${e.error}`);
            });
        }

        // Category breakdown from Atlas
        const total = await College.countDocuments();
        const eng = await College.countDocuments({ category: 'engineering' });
        const med = await College.countDocuments({ category: 'medical' });
        const pha = await College.countDocuments({ category: 'pharmacy' });
        const districts = await College.distinct('district');

        console.log(`\n📊 Total in MongoDB Atlas: ${total}`);
        console.log(`   🏗️  Engineering: ${eng}`);
        console.log(`   🏥 Medical:      ${med}`);
        console.log(`   💊 Pharmacy:     ${pha}`);
        console.log(`   🗺️  Districts:    ${districts.length}`);
        console.log('==================================\n');
        console.log('🎉 College data successfully uploaded to MongoDB Atlas!');

    } catch (err) {
        if (err.name === 'MongoServerSelectionError') {
            console.error('❌ Cannot connect to MongoDB Atlas. Please check:');
            console.error('   1. Your MONGODB_URI in .env is correct');
            console.error('   2. Your IP address is whitelisted in Atlas (Network Access → Add Current IP)');
            console.error('   3. Your username and password are correct');
        } else {
            console.error('❌ Seed failed:', err.message);
        }
    } finally {
        await mongoose.disconnect();
        console.log('🔌 Disconnected from MongoDB Atlas');
    }
}

seed();
